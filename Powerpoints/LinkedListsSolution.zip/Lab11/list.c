#include <stdlib.h>
#include <stdio.h>
#include "list.h"

typedef struct Node Node;

void add_front(struct Node **list, int value)
{
  Node *newNode = (Node *) malloc(sizeof(Node));
  newNode->number = value;

  if (*list)
    newNode->next = *list;
  else
    newNode->next = NULL;

  *list = newNode;
}
void add_back(struct Node **list, int value)
{
  Node *newNode = (Node *) malloc(sizeof(Node));
  Node *currentNode = *list;
  newNode->number = value;
  newNode->next = NULL;

  if (*list)
  {
    while (currentNode->next)
      currentNode = currentNode->next;

    currentNode->next = newNode;
  }
  else
    *list = newNode;
}
void free_list(struct Node *list)
{
  while (list)
  {
    Node *previousEntry = list;
    list = list->next;
    free(previousEntry);
  }
}
void print_list(const struct Node *list)
{
  while (list)
  {
    printf("%3i", list->number);
    list = list->next;
  }

  putchar('\n');
}
void remove_item(struct Node **list, int value)
{
  if (*list)
  {
    Node *previousEntry = *list;

    if ((*list)->number == value)
    {
      *list = (*list)->next;
      free(previousEntry);
    }
    else
    {
      Node *currentEntry = (*list)->next;

      while (currentEntry && (currentEntry->number != value))
      {
        previousEntry = currentEntry;
        currentEntry = currentEntry->next;
      }

      if (currentEntry && (currentEntry->number == value))
      {
        if (currentEntry->next)
        {
          Node *nextEntry = currentEntry->next;
          free(currentEntry);
          previousEntry->next = nextEntry;
        }
        else
        {
          previousEntry->next = NULL;
          free(currentEntry);
        }
      }
    }
  }
}
int size_list(const struct Node *list)
{
  int size = 0;

  while (list)
  {
    size++;
    list = list->next;
  }

  return size;
}
int sum_list(const struct Node *list)
{
  int total = 0;

  while (list)
  {
    total += list->number;
    list = list->next;
  }

  return total;
}