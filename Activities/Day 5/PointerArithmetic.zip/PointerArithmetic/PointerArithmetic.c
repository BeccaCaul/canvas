#include <stdio.h>
#include "PointerArithmetic.h"

/*
  Function name: Print2DArray
  Inputs       : int* array, int rows, int columns
  Outputs      : none
  
  Write a function called Print2DArray that takes
  in a pointer to an integer representing a 2D array,
  an integer containing the number of rows and an
  integer containing the number of columns. The function
  will print out the 2D array using pointer arithmetic
  in the following format:
  
  [1, 2, 3, 4]
  [5, 6, 7, 8]
  [9, 10, 11, 12]
  
  You will need two for loops with one inside the other. You
  must use pointer arithmetic here.
*/
void Print2DArray(int* array, int rows, int columns)
{
  /* Remember, array is now essentially a normal array,
     you will need to use two loops to solve this problem.
     One will loop through the rows, the other will loop
     through each element in the row. You will have to
     calculate the correct index in the one dimensional
     array based off both counter variables in the loops. */
}

/*
  Function name: TransposeArray
  Inputs       : int* array1, int* array2, int rows, int columns
  Outputs      : none
  
  Write a function called TransposeArray that takes in two pointers
  to integers representing 2D arrays, an integer containing the
  the number of rows and an integer containing the number of
  columns. The function will store the transpose of array1 in
  array2.
  
  Example:
  array1
  [1, 2, 3, 4]
  [5, 6, 7, 8]
  
  array2
  [1, 5]
  [2, 6]
  [3, 7]
  [4, 8]
  
  You will need two for loops with one inside the other. You
  must use pointer arithmetic here.
*/
void TransposeArray(int* array1, int* array2, int rows, int columns)
{
}
