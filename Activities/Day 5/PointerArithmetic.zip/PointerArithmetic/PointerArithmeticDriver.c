#include <stdio.h>
#include "PointerArithmetic.h"

int main(void)
{
  int array1[5][4];
  int array2[4][5];
  int array3[5];
  int array4[5];
  int i, j;
  
  for(i = 0; i < 5; ++i)
  {
    for(j = 0; j < 4; ++j)
    {
      array1[i][j] = i * j - j;
    }
  }
  
  for(i = 0; i < 5; ++i)
  {
    array3[i] = 5 * i / 2;
  }
  
  printf("Print2DArray test\n");
  Print2DArray((int*)array1, 5, 4);
  printf("\n");
  Print2DArray((int*)array3, 1, 5);
  printf("\n");
  
  printf("TransposeArray\n");
  TransposeArray((int*)array1, (int*)array2, 5, 4);
  Print2DArray((int*)array2, 4, 5);
  printf("\n");
  TransposeArray((int*)array3, (int*)array4, 1, 5);
  Print2DArray((int*)array4, 5, 1);
  
  return 0;
}
