void Print2DArray(int* array, int rows, int columns);
void TransposeArray(int* array1, int* array2, int rows, int columns);
