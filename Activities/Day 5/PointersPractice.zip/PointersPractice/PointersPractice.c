#include "PointersPractice.h"

/*
  Function name: Double
  Inputs       : float* number
  Outputs      : none
  
  Write a function that takes in a pointer to a float. Double the value
  stored at the pointer and store it back at the pointer.
  
  Ex
  Before: number is 5
  After: number is 10
*/
void Double(float* number)
{
}

/*
  Function name: Average
  Inputs       : float* data, int count
  Output       : float
  
  Write a function that takes in a pointer to the first element in an array
  of floats, an integer containing the number of elements in the array and
  returns a float. The function will calculate the average value in the array
  and return the result. Use pointer arithmetic to access the data in the
  array.
*/
float Average(float* data, int count)
{
  return 0; /* You will need to change this */
}

/*
  Function name: SwapArrays
  Inputs       : float* array1, float* array2, int count
  Outputs      : none
  
  Write a function that takes in two pointers to the first elements of
  two different arrays and an integer containing the number of elements in
  the arrays. The function will swap the contents of the two arrays.
  Use pointer arithmetic to access the data in the arrays.
*/
void SwapArrays(float* array1, float* array2, int count)
{
}
