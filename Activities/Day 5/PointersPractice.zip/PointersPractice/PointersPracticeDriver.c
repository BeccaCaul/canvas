#include <stdio.h>
#include "PointersPractice.h"

void PrintArray(float* array, int size)
{
  int i;
  printf("[%g", array[0]);
  for(i = 1; i < size; ++i)
  {
    printf(", %g", array[i]);
  }
  printf("]");
}

int main(void)
{
  float val = 4.5;
	float array1[] = {1, 2, 3, 4, 5};
	float array2[] = {6, 7, 8, 9, 10};
  
  printf("Double test\n");
  printf("Value: %g\n", val);
  Double(&val);
  printf("Doubled: %g\n\n", val);
  
  printf("Average test\n");
  printf("Array: ");
  PrintArray(array1, 5);
  printf("\nAverage %g\n", Average(array1, 5));
  printf("Array: ");
  PrintArray(array2, 5);
  printf("\nAverage %g\n\n", Average(array2, 5));
  
  printf("SwapArrays test\n");
  printf("Before:\n");
  PrintArray(array1, 5);
  printf("\n");
  PrintArray(array2, 5);
  printf("\nAfter:\n");
  SwapArrays(array1, array2, 5);
  PrintArray(array1, 5);
  printf("\n");
  PrintArray(array2, 5);
  
  return 0;
}
