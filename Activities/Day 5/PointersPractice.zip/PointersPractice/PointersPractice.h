void Double(float* number);
float Average(float* data, int count);
void SwapArrays(float* array1, float* array2, int count);
