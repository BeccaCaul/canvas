/*

Write a program that takes in three integers and printout the arrangement of those numbers that
makes the largest and the smallest number possible.

For example, if the input is 1,3,2 this program should print 321 as the greatest number and 123 
as the least. 

It should be able to take multidigit numbers, so if 24,6,18 is input, the program  will print 
62418 and 18246.

*/