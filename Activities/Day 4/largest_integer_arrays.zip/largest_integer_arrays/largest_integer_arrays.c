#include <stdio.h>
#define INPUTS 3

int findDigits(int x)
{
	/*count how many times it take to divide by 10 and get a single digit number*/
	int i = 1;
	while(x > 10)
	{
		++i;
		x /= 10;
	}
	/*return that number as the number of digits*/
	return i;
}

int findIfGreater(float x, float y)
{
	/*store the digits of each number*/
	int x_digits = findDigits(x);
	int y_digits = findDigits(y);
	
	/*divide by ten until they have the same number of digits*/
	while(x_digits > y_digits)
	{
		x /= 10;
		x_digits = findDigits(x);
	}
	while(y_digits > x_digits)
	{
		y /= 10;
		y_digits = findDigits(y);
	}
	/*return true if x is still greater*/
	if(x > y)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

int isSorted(int array[], int arraySize)
{
	/*check if the array is sorted correctly*/
	int i;
	for(i = 0; i < arraySize - 1; ++i)
	{
		if(findIfGreater(array[i+1], array[i]))
		{
			/*if the array is ever not in the right order, return false*/
			return 0;
		}
	}
	/*if it is all ordered, return true*/
	return 1;
}

int main(void)
{
	/*declare and get input for our variables*/
	int inputs[INPUTS];
	int i;
	
	for(i=0; i<INPUTS; ++i)
	{
		printf("Input a number: ");
		scanf("%d", &inputs[i]);
	}
	
	
	/*as long as they are out of greatest to least order, this loop will continue*/
	while(!isSorted(inputs, INPUTS))
	{
		int j;
		/*this loop will run through the array and sort it*/
		for(j = 0; j < INPUTS - 1; ++j)
		{
			if(findIfGreater(inputs[j+1], inputs[j]))
			{
				/*if two are out of order switch them*/
				int temp = inputs[j];
				inputs[j] = inputs[j+1];
				inputs[j+1] = temp;
			}
		}
	}
	/*print the values in greatest to least and least to greatest*/
	for(i=0; i<INPUTS; ++i)
	{
		printf("%d", inputs[i]);
	}
	printf("\n");
	for(i = INPUTS - 1; i >= 0; --i)
	{
		printf("%d", inputs[i]);
	}
	
	return 1;
}

