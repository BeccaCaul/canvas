#include "ArraysAdvanced.h"
/*
  Function name: ReverseArray
  Inputs       : int* array, int length
  Outputs      : none
  
  Write a function called ReverseArray that takes in
  an array of integers and an integer containing the length
  of the array.  The function will reverse the array.
*/

void ReverseArray(int array[], int length)
{
}

/*
  Function name: SwapArrays
  Inputs       : int* array1, int* array2, int length
  Outputs      : none
  
  Write a function called SwapArrays that takes in two
  arrays of integers and an integer containing the lengths
  of the arrays.  The function will swap the contents of the
  two arrays.
*/
void SwapArrays(int array1[], int array2[], int length)
{
}

/*
  Function name: BubbleSort
  Inputs       : int* array, int length
  Outputs      : none
  
  Write a function that takes in an array of integers
  and an integer containing the length of the array.
  The function will sort the array using a bubble sort.
*/

void BubbleSort(int array[], int length)
{
  /* Bubble sort psuedocode
    while the array is not sorted
      for each index in the array
        if the value at the index is greater than the value at the next index
          swap the values
  */
}

/*
  Function name: LinearSearch
  Inputs       : int* array, int length, int value
  Outputs      : int
  
  Write a function that takes in an array of integers,
  an integer containing the length of the array and an
  integer containing the value to search for. The function
  will perform a linear search through the array for the
  given value and return the index containing the value.
  If the value was not found, it will return -1.
*/

int LinearSearch(int array[], int length, int value)
{
  /* Linear search psuedocode
    for each index in the array
      if the value at the index is the value being searched for
        return the index
    if not found
      return -1
  */
}

/*********** Challenges ***********/

/*
  Function name: BinarySearch
  Inputs       : int* array, int length, int value
  Outputs      : int
  
  Write a function that takes in an array of integers,
  an integer containing the length of the array and an
  integer containing the value to search for. The funtion
  will perform a binary search through a sorted array,
  assume the array is sorted when it's passed in,
  and return the index containing the value.
  If the value was not found, it will return -1.
*/
int BinarySearch(int array[], int length, int value)
{
  /* Binary search psuedocode
    set L to 0 and R to length - 1
    while index L is less than index R
      set m to the middle of L and R
      if value at index m == search value
        return index m
      if value at index m < search value
        set L to m + 1
      if value at index m > search value
        set R to m - 1
    (if we get here, the value was not found)
    return -1
  */
}

/*
  Function name: SelectionSort
  Inputs       : int* array, int length
  Outputs      : none
  
  Write a function that takes in an array of integers
  and an integer containing the length of the array.
  The function will perform a selection sort on the array.
*/
void SelectionSort(int array[], int length)
{
  /* Selection sort psuedocode
    for indexes 0 to length - 2
      find the smallest value in the unsorted portion of the array
        swap the smallest value with the current index
    
    Example:
    original array
    4 5 9 2 1 4
    
    after index 0
    1 5 9 2 4 4
    after index 1
    1 2 9 5 4 4
    after index 2
    1 2 4 5 9 4
    after index 3
    1 2 4 4 9 5
    after index 4
    1 2 4 4 5 9
    array is now sorted
  */
}

