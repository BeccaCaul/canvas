#include <stdio.h>
#include <stdlib.h>
#include "ArraysAdvanced.h"

void PrintArray(int array[], unsigned size)
{
  printf("[");
  
  if(size > 0)
  {
    unsigned i;
    printf("%i", array[0]);
    for(i = 1; i < size; ++i)
    {
      printf(", %i", array[i]);
    }
  }
  
  printf("]");
}

int main(void)
{
  int reverse[] = {1, 2, 3, 4, 5};
  int swap1[] = {3, 1, 4, 1, 5, 9};
  int swap2[] = {2, 7, 1, 8, 2, 8};
  int bubble[10] = {10, 3, 7, 6, 2, 1, 9, 4, 5, 8};
  int linear[10] = {10, 3, 7, 6, 2, 1, 9, 4, 5, 8};
  int binary[10] = {1, 5, 6, 7, 9, 15, 17, 20, 21, 25};
  int selection[10] = {10, 3, 7, 6, 2, 1, 9, 4, 5, 8};
  int i;
  
  printf("Reverse Test\n");
  printf("Array: ");
  PrintArray(reverse, 5);
  ReverseArray(reverse, 5);
  printf("\nReversed Array: ");
  PrintArray(reverse, 5);
  
  printf("\n\nSwap Test\n");
  printf("Originals:\n");
  printf("Array1: ");
  PrintArray(swap1, 5);
  printf("\nArray2: ");
  PrintArray(swap2, 5);
  SwapArrays(swap1, swap2, 5);
  printf("\n\nSwapped:\n");
  printf("Array1: ");
  PrintArray(swap1, 5);
  printf("\nArray2: ");
  PrintArray(swap2, 5);
  
  printf("\n\nBubble Sort Test\n");
  printf("Array: ");
  PrintArray(bubble, 10);
  BubbleSort(bubble, 10);
  printf("\nSorted: ");
  PrintArray(bubble, 10);
  
  printf("\n\nLinear Search Test\n");
  printf("Array: ");
  PrintArray(linear, 10);
  printf("\nSearching for 6: ");
  i = LinearSearch(linear, 10, 6);
  if(i == -1)
    printf("Not Found");
  else
    printf("Found at %i", i);
    
  printf("\nSearching for 20: ");
  i = LinearSearch(linear, 10, 20);
  if(i == -1)
    printf("Not Found");
  else
    printf("Found at %i", i);
    
  printf("\n\nBinary Search Test\n");
  printf("Array: ");
  PrintArray(binary, 10);
  printf("\nSearching for 6: ");
  i = BinarySearch(binary, 10, 6);
  if(i == -1)
    printf("Not Found");
  else
    printf("Found at %i", i);
    
  printf("\nSearching for 8: ");
  i = BinarySearch(binary, 10, 8);
  if(i == -1)
    printf("Not Found");
  else
    printf("Found at %i", i);
    
  printf("\n\nSelection Sort Test\n");
  printf("Array: ");
  PrintArray(selection, 10);
  SelectionSort(selection, 10);
  printf("\nSorted: ");
  PrintArray(selection, 10);
  
  return 0;
}
