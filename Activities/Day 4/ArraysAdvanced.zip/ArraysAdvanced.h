void ReverseArray(int array[], int length);
void SwapArrays(int array1[], int array2[], int length);
void BubbleSort(int array[], int length);
int LinearSearch(int array[], int length, int value);
int BinarySearch(int array[], int length, int value);
void SelectionSort(int array[], int length);
