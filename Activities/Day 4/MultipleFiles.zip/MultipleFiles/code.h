float Quadruple(float number);
