float Quadruple(float number)
{
  return 4 * number;
}
