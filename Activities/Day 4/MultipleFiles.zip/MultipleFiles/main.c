#include <stdio.h>
#include "code.h"

int main(void)
{
  int input;
  int answer;
  
  printf("Enter a number: ");
  scanf("%i", &input);
  
  answer = Quadruple(input);
  printf("%i quadrupled is: %i", input, answer);
  
  return 0;
}
