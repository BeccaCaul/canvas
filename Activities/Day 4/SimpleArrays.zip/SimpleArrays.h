void PrintArrayFloat(float array[], int arraySize);
void PrintArrayInt(int array[], int arraySize);
void AddArraysFloat(float array1[], float array2[], int arraySize);
void SetArray(int array[], int arraySize, int value);
int CompareArray(int array1[], int array2[], int arraySize);
int DotProduct(float array1[], float array2[], int arraySize);
