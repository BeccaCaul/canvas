typedef struct Time
{
  int hours;
  int minutes;
  int seconds;
}Time;

void PrintTime(Time time);
Time AddTimes(Time time1, Time time2);
Time SubtractTimes(Time time1, Time time2);
