#include "Time.h"
#include <stdio.h>

int main(void)
{
  Time time1 = {5, 32, 18};
  Time time2 = {2, 38, 12};
  
  printf("PrintTime test\n");
  printf("time1: ");
  PrintTime(time1);
  printf("\ntime2: ");
  PrintTime(time2);
  
  printf("\n\nAddTimes test\n");
  printf("time1 + time2 = ");
  PrintTime(AddTimes(time1, time2));
  
  printf("\n\nSubtractTimes test\n");
  printf("time1 - time2 = ");
  PrintTime(SubtractTimes(time1, time2));
  
  return 0;
}
