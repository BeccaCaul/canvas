#include "Time.h"
/* Look inside Time.h for the Time struct definition */

/*
  Function name: PrintTime
  Inputs       : Time time
  Outputs      : None
  
  Write a function that takes in a Time struct. The function will
  print out the time in the followinging format:
  
  hh:mm:ss
  
  Ex
  If time has 12 hours, 23 minutes and 16 seconds, you would print:
  12:23:16
  
  If the time has 1 hour, 1 minute and 1 second, you would print:
  01:01:01
*/
void PrintTime(Time time)
{
}

/*
  Function name: AddTimes
  Inputs       : Time time1, Time time2
  Outputs      : Time
  
  Write a function that takes in two Time structs and returns a
  Time struct. The function will add the two time structs together.
  Make sure you do the addition properly. 60 seconds is a minute, 60 minutes
  is an hour. The function will then return the new time;
  
  Ex
  time1: 04:30:20
  time2: 02:36:10
  
  result: 07:06:30
*/
Time AddTimes(Time time1, Time time2)
{
}
 
/* Challenge
  Function name: SubtractTimes
  Inputs       : Time time1, Time time2
  Outputs      : Time
  
  Write a function that takes in two Time structs and returns a
  Time struct. The function will subtract time2 from time1.
  Make sure you do the subtraction properly. Borrow from an hour or a minute
  if you need to. time1 will allways be larger than time2.
  The function will then return the new time;
  
  Ex
  time1: 04:30:20
  time2: 02:36:10
  
  result: 01:54:10
*/
Time SubtractTimes(Time time1, Time time2)
{
}
