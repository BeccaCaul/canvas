#include <stdio.h>
#include <string.h>
#include "ReadWrite.h"

void writeFile(const char* string, FILE* fp)
{
	/* write the string passed to the file
	 * pointed to by fp */

}

void readFile(FILE* fp)
{
	/* declare a buffer to store the read characters */

	/* read the string from the file pointed
	 * to by fp and print it to the console (printf) */

}