void writeFile(const char* string, FILE* fp);
void readFile(FILE* fp);