#include <stdio.h>
#include <string.h>
#include "ReadWrite.h"

int main(void)
{
	const char* string = "Congrats! You've successfuly wrote to and read from a file.";
	
	/* declare a file pointer */
	
	/* open a file named "SCS.txt" for writing */
	
	/* check if it was successful */

		/* if it wasn't, print out an error message
		 * and return -1 */

	
	/* call writeFile, passing it the string and the file pointer*/
	

	/* close the file */

	/* reopen the file for reading */

	/* check if it was successful */

		/* if it wasn't, print out an error message
		 * and return -1 */

		 
	/* call readFile with the appropriate arguments */

	/* close the file */

	return 0;
}

