#include <stdio.h>
#include "AdventureUtils.h"

typedef struct Fighter
{
  char* Name;
  int Health;
  int Attack;
  int Defense;
}Fighter;

int HaveBattle(Fighter* fighter1, Fighter* fighter2)
{
  int turn = 0;
  printf("Fight between %s and %s\n", fighter1->Name, fighter2->Name);
  while(fighter1->Health > 0 && fighter2->Health > 0)
  {
    int roll1 = RollDie(6);
    int roll2 = RollDie(6);
    
    if(turn == 0)
    {
      int attack = fighter1->Attack + roll1;
      int defense = fighter2->Defense + roll2;
      if(attack > defense)
      {
        int damage = attack - defense;
        fighter2->Health -= (damage);
        printf("%s took %i damage, %i health remaining\n", fighter2->Name, damage, fighter2->Health);
      }
      else
      {
        printf("%s missed\n", fighter1->Name);
      }
      turn = !turn;
    }
    else
    {
      int attack = fighter2->Attack + roll2;
      int defense = fighter1->Defense + roll1;
      if(attack > defense)
      {
        int damage = attack - defense;
        fighter1->Health -= (damage);
        printf("%s took %i damage, %i health remaining\n", fighter1->Name, damage, fighter1->Health);
      }
      else
      {
        printf("%s missed\n", fighter2->Name);
      }
      turn = !turn;
    }
    getchar();
  }
  
  if(fighter1->Health > fighter2->Health)
  {
    printf("%s was victorious!", fighter1->Name);
    return 1;
  }
  else
  {
    printf("%s was victorious!", fighter2->Name);
    return 2;
  }
}

int main(void)
{
  Fighter chris = {"Chris", 10, 5, 6};
  Fighter adrian = {"Adrian", 15, 4, 5};
  HaveBattle(&chris, &adrian);
  return 0;
}
