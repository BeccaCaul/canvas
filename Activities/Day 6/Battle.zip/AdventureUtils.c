#include <stdlib.h>
#include <time.h>
#include "AdventureUtils.h"

static int NeedInit = 1;

float RandomFloat(float min, float max)
{
  if(NeedInit)
  {
    srand(time(NULL));
    NeedInit = 0;
  }
  
  return ((float)rand() / RAND_MAX) * (max - min) + min;
}

int RandomInt(int min, int max)
{
  if(NeedInit)
  {
    srand(time(NULL));
    NeedInit = 0;
  }
  
  return rand() % (max - min + 1) + min;
}

int RollDie(int sides)
{
  return RandomInt(1, sides);
}

void StringToUpper(char* string)
{
  while(*string)
  {
    if(*string >= 'a' && *string <= 'z')
      *string -= 32;
    
    ++string;
  }
}

void StringToLower(char* string)
{
  while(*string)
  {
    if(*string >= 'A' && *string <= 'Z')
      *string += 32;
    
    ++string;
  }
}

void ClearScreen(void)
{
  system("cmd /c cls");
}
