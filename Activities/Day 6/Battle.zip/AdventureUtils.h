#ifndef ADVENTURE_UTILS_H
#define ADVENTURE_UTILS_H

/* For creating random numbers */
float RandomFloat(float min, float max);
int RandomInt(int min, int max);
int RollDie(int sides);

/* String to upper or lower */
void StringToUpper(char* string);
void StringToLower(char* string);

/* Clearing the screen */
void ClearScreen(void);

typedef struct Room
{
  /* A string describing the room */
  char* Description;
  /* Ascii art to display */
  char* AsciiArt;
  /* If you can go north from here */
  int North;
  /* If you can go east from here */
  int East;
  /* If you can go south from here */
  int South;
  /* If you can go west from here */
  int West;
} Room;

#endif
